package dosyaıslemsistemi;

import java.util.Scanner;

public class Excel extends Dosya {

    static String dosyaUzantisi = "xlsx";
    private int satirSayisi;
    private int sutunSayisi;
    Scanner scan = new Scanner(System.in);
    String[][] excelmatris=new String[satirSayisi][sutunSayisi];
    public Excel(String dosyaIsmi) {
        super(dosyaIsmi);

    }

    @Override
    public void setDosyaUzantisi(String dosyaUzantisi) {
        this.dosyaUzantisi = dosyaUzantisi;
        super.setDosyaUzantisi(dosyaUzantisi);

    }

    @Override
    public void dosyaBilgiGoster(Dosya girdi) {
        setDosyaUzantisi(dosyaUzantisi);
        super.dosyaBilgiGoster(girdi);

    }

    public void dosyayiAc() {
        if (satirSayisi == 0 && sutunSayisi == 0) {
            System.out.println("şuanki excel dosyası boş.");
            System.out.println("Satır sayısını giriniz:");
            int girdi=scan.nextInt();
            this.satirSayisi=girdi;
            System.out.println("Sütun sayısını giriniz:");
            int girdi1=scan.nextInt();
            this.sutunSayisi=girdi1;
            System.out.println("şuanda bu excel dosyasında:");
            System.out.println(satirSayisi+"satır");
            System.out.println(sutunSayisi+"sütun bulunamktadır.");
            }else {
            System.out.println("şuanda bu excel dosyasında:");
            System.out.println(satirSayisi+"satır");
            System.out.println(sutunSayisi+"sütun bulunamktadır.");
        }
    }
}
