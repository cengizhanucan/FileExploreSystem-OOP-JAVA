package dosyaıslemsistemi;

import java.util.ArrayList;
import java.util.Scanner;

public class Word extends Dosya {

    Scanner scan = new Scanner(System.in);
    String dosyaUzantisi = "doc";
    ArrayList<String> metin = new ArrayList<String>();
    

    public Word(String dosyaIsmi) {
        super(dosyaIsmi);
        this.dosyaUzantisi = dosyaUzantisi;
        ArrayList<String> metin2 = new ArrayList<String>();
    }

    void metinYazveKaydet() {
        int MaksKelimeSayisi = 2560;
        System.out.println("--------------------------");
        System.out.println("yazcağınız metni yazınız. metin yazma işlemi bittikten"
                      + " sonra enter'a basınız ve klavyenizden ! tuşuna basınız");
        System.out.println(" ");
        int i = 0;
        while (i < MaksKelimeSayisi) {
            if (!metin.contains("!")) {

                String tarananMetin = scan.next();
                metin.add(tarananMetin);
            } else {
                metin.remove(metin.size() - 1);
                break;
            }
        }
        System.out.println("metni görmek ister misiniz? Görmek için y'ye, iptal etmek için n'ye tıklayınız.");
        char y1 = scan.next().charAt(0);

        if (y1 == 'y') {
            for (int j = 0; j < metin.size(); j++) {
                System.out.print(" " + metin.get(j) + " ");
               
            }
            System.out.println("");
        } else if (y1 == 'n') {
            System.out.println("İşlem İptal Edildi.");
        } else {
            System.out.println("y veya n seçmeniz gerekir.");
        }
    }

    public void dosyayiAc() {
        super.dosyayiAc();
        metinYazveKaydet();
        System.out.println("dosya başarıyla açıldı.");
    }

    @Override
    public void setDosyaUzantisi(String dosyaUzantisi) {
        this.dosyaUzantisi = dosyaUzantisi;
        super.setDosyaUzantisi(dosyaUzantisi);

    }

    @Override
    public void dosyaBilgiGoster(Dosya girdi) {
        setDosyaUzantisi(dosyaUzantisi);
        super.dosyaBilgiGoster(girdi);

    }

}
