package dosyaıslemsistemi;

import java.util.Scanner;

public class Dosya {

    Scanner scan = new Scanner(System.in);
    int dosyaBoyutu;
    String dosyaIsmi;
    String dosyaUzantisi;

    public Dosya(String dosyaIsmi) {
//        this.dosyaBoyutu = dosyaBoyutu;
        this.dosyaIsmi = dosyaIsmi;
//        this.dosyaUzantisi = dosyaUzantisi;
    }

     int getDosyaBoyutu() {
        return dosyaBoyutu;
    }

     void setDosyaBoyutu(int dosyaBoyutu) {
        this.dosyaBoyutu = dosyaBoyutu;
    }

     String getDosyaIsmi() {
        return dosyaIsmi;
    }

     void setDosyaIsmi(String dosyaIsmi) {
        this.dosyaIsmi = dosyaIsmi;
    }

     String getDosyaUzantisi() {
        return dosyaUzantisi;
    }

     void setDosyaUzantisi(String dosyaUzantisi) {
        this.dosyaUzantisi = dosyaUzantisi;
    }

     void DosyaKopyalama(String DosyaIsmi) {
        this.dosyaIsmi = DosyaIsmi;
    }

     void dosyaBilgiGoster(Dosya girdi) {
        this.dosyaUzantisi = girdi.dosyaUzantisi;
        System.out.println(girdi.dosyaIsmi + "." + girdi.dosyaUzantisi + "  ");

    }

     void dosyayiAc() {
        System.out.println("dosya başarıyla açıldı.");
    }


    @Override
    public String toString() {
        return "dosya:" + dosyaIsmi + "." + dosyaUzantisi;
    }
}