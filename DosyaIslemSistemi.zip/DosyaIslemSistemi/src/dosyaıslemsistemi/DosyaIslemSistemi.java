package dosyaıslemsistemi;

public class DosyaIslemSistemi {

    public static void main(String[] args) {
        Folder f1=new Folder();
        f1.dosyaIslemSistemi();
        
        
    }

}
